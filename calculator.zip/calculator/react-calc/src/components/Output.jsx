import React from 'react';
export const Output=(props)=><div className='alert-success'>
     Result is {props.result}</div>