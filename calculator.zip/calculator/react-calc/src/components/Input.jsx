import React from 'react';
import { useRef } from 'react';
export const Input = (props)=>{
    const val=useRef();
    console.log(val);
    //console.log('Input ReRender ',props);
    var pmsg = `Type ${props.name} Number Here`;
    return (<div className='form-group'>
        <label>{props.name} Number</label>
        <input ref={val} id={props.name} type='text' onKeyUp={props.input} placeholder={pmsg} className='form-control'/>
    </div>)
}