import {configureStore} from '@reduxjs/toolkit';
import productSlice from '../modules/products/redux/user-slice';
// App State Store here
export const store = configureStore({
    reducer:{productSlice: productSlice}
})