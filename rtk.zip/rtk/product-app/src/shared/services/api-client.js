import axios from "axios"
export const apiClient={
    async get(url){
     try{  
        const response= await axios.get(url);
        return response;
    }
    catch(err){
        return err;
    }
    }
}