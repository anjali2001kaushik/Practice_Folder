import React from 'react'
import AddProduct from '../modules/products/components/AddProduct'
import ViewProducts from '../modules/products/components/ViewProducts'
const Home = () => {
  return (
    <div>
      <AddProduct/>
      <br />
      <ViewProducts/>
      {/* <p>I'm a Home</p> */}
    </div>
  )
}

export default Home
