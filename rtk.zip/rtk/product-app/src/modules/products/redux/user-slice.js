import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { apiClient } from "../../../shared/services/api-client";
//jis nam se asyncthunk bnega usi nam se uska action bnega
export const fetchProducts=createAsyncThunk('fetch-products',async()=>{
    const response= await apiClient.get(process.env.REACT_APP_PRODUCTS);
    console.log('Response',response);
    return response.data;
})

const productSlice=createSlice({
name:'product-slice',
initialState:{products:[],searchProduct:[],total:0,loading:false,error:null},
reducers:{
    addProduct(state,action){
        const product=action.payload;
        console.log('Product%%%%%%%%',product);
        state.products.push(product);
        console.log("state",state.products);
        state.total=state.products.length;
    },
    searchProduct(state,action){
        const product=action.payload;
        console.log('searched product',product);
        
        state.searchProduct.push(product);
        state.total=state.searchProduct.length;

    }

},
extraReducers:{
    //Async
    [fetchProducts.pending]:(state,action)=>{
        state.loading=true;

    },
    [fetchProducts.fulfilled]:(state,action)=>{
        state.loading=false;
        state.products=[...state.products,...action.payload];
    },
    [fetchProducts.rejected]:(state,action)=>{
        state.loading=false;
        state.error=action.payload;
    }
}
});
export default productSlice.reducer;//give to store
export const {addProduct,searchProduct,sortProduct}=productSlice.actions;
//state comes from store
//action comes from components