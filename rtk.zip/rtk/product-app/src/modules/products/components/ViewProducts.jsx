import React from 'react'
import { useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import { fetchProducts } from '../redux/user-slice';
import SearchProduct from './SearchProduct';
const ViewProducts = () => {
    const {products,searchedProducts,loading,total} = useSelector(state=>state.productSlice);
    console.log('::::: Products are ', products,'searchedproducts are ',searchedProducts, 'and Loading are ',loading);
    console.log("LENGTH ISSSSSSSS",total);
    const dispatch = useDispatch();
    useEffect(()=>{
      dispatch(fetchProducts());
    },[]);
    
  return (
    <div>
      <SearchProduct products={products}/>
    {total==1?searchedProducts:
    <>{loading?<p> Fetching Products...</p>:products.map((product,index)=><p key ={index} >{product.id} '{product.title}' PRICE: {product.price}</p>)}</>}

      {/* <SearchProduct products={products} />
      {loading?<p> Fetching Products...</p>:products.map((product,index)=><p key ={index} >{product.id} '{product.title}' PRICE: {product.price}</p>)}  */}

    </div>
  )
}

export default ViewProducts
