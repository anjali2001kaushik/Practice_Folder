import React from 'react'
import { addProduct } from '../redux/user-slice';
import {useDispatch} from 'react-redux';
import { useRef } from 'react';

const AddProduct = () => {
    const id = useRef();
    const name = useRef();
    const price = useRef();
    const url = useRef();
    const dispatch = useDispatch();
    const addNewProduct = ()=>{
            const product = {'id':id.current.value, 'name':name.current.value,'price':price.current.value,'url':url.current.value};
            // dispatch contains action name , and action contains payload (data)
            dispatch(addProduct(product)); // Send data to reducer
    }
  return (
<div>
        <h1>RTK implemented Along with async calls</h1>
        <h1>Product Info</h1>
        <input ref = {id} type = 'text' placeholder='Type productid here'/>
        <br/>
        <input ref = {name} type = 'text' placeholder='Type productname here'/>
        <br/>
        <input ref = {price} type = 'number' placeholder='Type price here'/>
        <br />
        <input ref = {url} type = 'text' placeholder='Type url here'/>
        <button onClick={addNewProduct}>Add Product</button>
        
    </div>
  )
}


export default AddProduct;
