import React from 'react'
import { useState } from 'react';
// import Button from '../../../shared/widgets/Button';
import { useDispatch } from 'react-redux';
import { searchProduct } from '../redux/user-slice';

const SearchProduct = ({products}) => {
  console.log('CCCCCCCCC',products);
  const [message, setMessage] = useState(' ');
  const dispatch=useDispatch();
  const search=(message,products)=>{
    console.log('MMMMMMM',message);
    console.log('1111111 Products are',products);
  const product= products.filter(product=> product.title===message);
  console.log('=============',product);
  dispatch(searchProduct(product));
  }
  const handleChange=(event)=>{
    setMessage(event.target.value);
    
    console.log('value is:', event.target.value);
    
    
    
  }
  return (
    <span>
    <div className="input-group rounded">
    <input type="search" className="form-control rounded" placeholder="Search" onChange={handleChange} value={message} />
    <span className="input-group-text border-0" >
      <i className="fas fa-search"></i>
    </span><button onClick={()=>{search(message,products)}}>Search</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     </div>
     </span>
  )
}

export default SearchProduct
