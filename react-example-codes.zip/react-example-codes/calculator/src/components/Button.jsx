import { useState } from "react";

export const Button=({label,myclass})=>{
    const[val,setVal]=useState(" ");
    const toggle=()=>{
        setVal=(label);
        // console.log("val",val);
    }
    
    let myClassname=`btn btn-${myclass} btn-lg`;
    
   return(<button onClick={toggle}  className= {myClassname}>{label} </button>) 
}