export const Result=({val})=>{
    return(<h3>{val}</h3>)
}