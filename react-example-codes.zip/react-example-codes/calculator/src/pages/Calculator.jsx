import { useState } from "react"
import { Button } from "../components/Button"
import { Result } from "../components/Result"
export const Calculator=({fn})=>{
    const[val,setval]=useState(" ");
    const toggleIt=()=>{
        fn();
        setval=
    }

    return(<div className="container d-grid gap-4 d-md-block">
        <h1 className='alert-info text-centre'>Calculator</h1>
        <br></br>
        <br></br>
           <Result  val={} />
        <br></br>
        <br></br>
        <br></br>
        <Button  label="(" myclass="secondary" fn={toggleIt} />&nbsp;
        <Button label=")" myclass="secondary" fn={toggleIt}/>&nbsp;
        <Button label="%" myclass="secondary" fn={toggleIt} />&nbsp;
        <Button label="AC" myclass="secondary" fn={toggleIt}/><br></br>         
        <Button label="7" myclass="secondary" />&nbsp;
        <Button label="8" myclass="secondary" />&nbsp;
        <Button label="9" myclass="secondary" />&nbsp;
        <Button label="÷" myclass="secondary" /><br></br>
        <Button label="4" myclass="secondary" />&nbsp;
        <Button label="5" myclass="secondary" />&nbsp;
        <Button label="6" myclass="secondary" />&nbsp;
        <Button label="X" myclass="secondary" /><br></br>
        <Button label="1" myclass="secondary" />&nbsp;
        <Button label="2" myclass="secondary" />&nbsp;
        <Button label="3" myclass="secondary" />&nbsp;
        <Button label="-" myclass="secondary" /><br></br>
        <Button label="0" myclass="secondary" />&nbsp;
        <Button label="." myclass="secondary" />&nbsp;
        <Button label="+" myclass="secondary" />&nbsp;
        <Button label="=" myclass="primary" />&nbsp;        
    </div>)

}