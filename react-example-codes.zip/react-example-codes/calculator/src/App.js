import { Calculator } from "./pages/Calculator";

const App=()=>{
    return(<Calculator/>)
}
export default App;