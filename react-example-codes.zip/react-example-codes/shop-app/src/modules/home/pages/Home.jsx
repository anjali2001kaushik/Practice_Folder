import React from 'react'
import Header from '../../../shared/components/Header'
import Product from '../components/Product'
import Products from '../components/Products'

const Home = () => {
  return (
    <div>
      <Header/>
        {/* <Product name='Corn Pizza' /> */}
        <Products/>
    </div>
  )
}

export default Home