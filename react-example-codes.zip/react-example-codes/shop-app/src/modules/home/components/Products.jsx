import React from 'react'
import { Pizzas } from '../../../app/pizza-store'
import Product from './Product'

const Products = () => {
  const pizzas=(Pizzas.Vegetarian);
  console.log(pizzas);
  return (
    <div>
      <div className="d-flex flex-wrap">
      {pizzas.map(pizza=><div key={pizza.id}>
        <img src={pizza.url} alt={pizza.name} />
        
        <Product name={pizza.name} menu_description={pizza.menu_description} url={pizza.assets.product_details_page[0].url} />
      
      </div>)}
      </div>
      {/* <Product name={pizzas.name} menu_description={pizzas.menu_description} /> */}
    </div>
  )
}

export default Products