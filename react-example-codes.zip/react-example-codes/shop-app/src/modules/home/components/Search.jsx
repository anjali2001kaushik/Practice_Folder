import React, { useState } from 'react'
import { Pizzas } from '../../../app/pizza-store'
import Button from '../../../shared/widgets/Button'


const Search = () => {
  const pizzas=Pizzas.Vegetarian;
  const [message, setMessage] = useState(' ');
  const search=(message)=>{
    console.log(message);
  return pizzas.find(pizza=>pizza.name===message);
    
  }
  const handleChange=(event)=>{
    setMessage(event.target.value);
    console.log('value is:', event.target.value);
    // return pizzas.find(pizza=>pizza.name==message);
  }
  return (
    <span>
    <div className="input-group rounded">
    <input type="search" className="form-control rounded" placeholder="Search" onChange={handleChange} value={message} />
    <span className="input-group-text border-0" >
      <i className="fas fa-search"></i>
    </span><Button onClick={()=>{search(message)}} myClass="primary" label="Search"/> &nbsp;&nbsp;&nbsp;&nbsp;
     </div>
     </span>
  )
}

export default Search