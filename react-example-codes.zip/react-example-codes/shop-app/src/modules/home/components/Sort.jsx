import React from 'react'
import Button from '../../../shared/widgets/Button'
import DropDown from '../../../shared/widgets/DropDown'

export const Sort = () => {
  return (
    <span>
        <DropDown typeDrop='Sort' myClass='primary' />
        {/* <Button myClass='primary lg' label='Sort' /> */}
    </span>
  )
}
