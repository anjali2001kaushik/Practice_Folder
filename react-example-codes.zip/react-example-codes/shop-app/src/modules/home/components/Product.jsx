import React from 'react'
import Price from '../../../shared/widgets/Price';
const Product = ({name,menu_description,url}) => {
  const myStyle={
    width: '20rem'
  };
  return (
    <div className="card" style={myStyle} >
    <img className="card-img-top" src={url} alt="Card image cap"/>
    <div className="card-body">
      <h5 className="card-title">{name}</h5> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <Price/>
      <p className="card-text">{menu_description}</p>
    </div>
  </div>
  )
}
export default Product