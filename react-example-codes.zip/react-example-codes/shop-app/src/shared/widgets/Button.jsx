import React from 'react'

const Button = ({myClass,label}) => {
    let myClassname= `btn btn-${myClass}`;
  return (
    <button className={myClassname}>{label}</button>

  )
}

export default Button