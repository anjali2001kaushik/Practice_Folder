import React from 'react'

const Icon = ({icon}) => {
  let iconName=`${icon}`
  return (
    <FontAwesomeIcon icon={iconName} />
    // <FontAwesomeIcon icon="fa-solid fa-circle" />
    // <FontAwesomeIcon icon="fa-solid fa-triangle" />
  )
}

export default Icon