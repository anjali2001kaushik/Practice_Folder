import React from 'react'

const Price = ({price}) => {
  return (
    <div>{price}</div>
  )
}

export default Price