import React from 'react'
import Button from './Button';
const DropDown = ({typeDrop,myClass}) => {
  let myClassName=`btn btn-${myClass} dropdown-toggle`;
  return (
    <div className="dropdown">
    <button className={myClassName} type="button" data-bs-toggle="dropdown" aria-expanded="false">
      {typeDrop}
    </button>
    <ul className="dropdown-menu">
      <li><a className="dropdown-item active" href="#">Action</a></li>
      <li><a className="dropdown-item" href="#">Another action</a></li>
      <li><a className="dropdown-item" href="#">Something else here</a></li>
    </ul>
  </div>
  // <div>
  
  
  // <Button label='Sort' myClass='primary'/>
  // <select>
  //   {/* <option>...</option> */}
  //   <option>value1</option>
  //   <option >value2</option>
  // </select>
  // </div>
  )
}

export default DropDown
