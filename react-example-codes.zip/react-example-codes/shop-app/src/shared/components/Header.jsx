import React from 'react'
import Search from '../../modules/home/components/Search'
import { Sort } from '../../modules/home/components/Sort'
import Button from '../widgets/Button'

const Header = () => {
  return (
    <nav className="navbar bg-body-tertiary">
    <div className="container">
      {/* <a className="navbar-brand" href="#"> */}
        {/* <img src="/docs/5.3/assets/brand/bootstrap-logo.svg" alt="Bootstrap" width="30" height="24"/> */}

        <Search />
        <Sort />
        
      {/* </a> */}
    </div>
  </nav>
  )
}

export default Header