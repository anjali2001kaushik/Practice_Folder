import { useState } from "react";
import { Button } from "../components/Button"
import { Label } from "../components/Label"

export const CounterApp=()=>{
    //Destructure---- usestate give two things get and set
    console.log('Call Again...');

   const[count,setCount]= useState(0);//Old state from it //state initialized with 0 state mein change krne se re-rendering hogi
        // let count=0;
        const plus=()=>{
            // count= count+1;
            setCount(count+1);//changes In Immutable way(New State)
            console.log('Plus Count is ', count);
        }
        const minus=()=>{
            // count= count-1;
            setCount(count-1);
            //console.log('Minus Count is ', count2);
        }
    return (<>
        <Label title="Counter App"/>
        <Button fn = {plus} label="+" myclass="success"/> &nbsp;
        <Button fn = {minus} label="-" myclass="danger"/>
        <Label title = "Counter is " val = {count}/>
    </>)
}