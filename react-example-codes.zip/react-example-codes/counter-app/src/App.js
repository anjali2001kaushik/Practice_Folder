import { CounterApp } from "./pages/CounterApp"

const App = ()=>{
  return (<CounterApp/>)
}
export default App;