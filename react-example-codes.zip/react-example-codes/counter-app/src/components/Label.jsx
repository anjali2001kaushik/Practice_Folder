export const Label = ({title, val})=>{
    return (<h3>{title}  {val}</h3>)
}