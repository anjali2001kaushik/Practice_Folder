export const Button=({label,myclass,fn})=>{
    let myClassname=`btn btn-${myclass}`;
    return (<button onClick={fn} className={myClassname}> {label}</button>)
}