import React, { useState } from 'react'
import { UserContext } from '../../../app/user-context';
import Login from '../components/Login'
import Register from '../components/Register'

const Home = () => {
    const [screenFlag,setScreenFlag]=useState(true);
    const[userInfo,setUserInfo]=useState({});
    const toggleIt=()=>{
        setScreenFlag(!screenFlag);
    }

  return (
    <div  className='container' >
        <button className='btn btn-info' onClick={toggleIt} >{screenFlag?"Register":"Login"}</button>
        <UserContext.Provider value={{user:userInfo,setUser:setUserInfo}}>
            {screenFlag?<Login/>:<Register/>}
        </UserContext.Provider>
      
    </div>
  )
}

export default Home
