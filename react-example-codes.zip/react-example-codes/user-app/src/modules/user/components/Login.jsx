import React, { useContext } from 'react'
import {UserContext} from '../../../app/user-context';
import { collection, query, where, getDocs } from "firebase/firestore";
import {firestore} from "../../../settings/firebase/config";
import { useRef } from 'react';
const Login = React.memo(() => {
  const userid=useRef();
  const password=useRef();
  const name=useRef();
  const  context=useContext(UserContext);
  const doLogin= async ()=>{
    const userIdValue=userid.current.value;
    const passwordValue = userid.current.value;
    const q1=query(collection(firestore,"users"),where("userid","==",userIdValue,"password","==",passwordValue));
    if(userIdValue){
      throw new Error('Simulating the Error For Error Boundary')
    }
    const querySnapShot=await getDocs(q1);
    querySnapShot.forEach((doc)=>{
      console.log(doc.id,"User Login==>", doc.data());
    });
  }

  return (
    <>
    <p>Welcome {context?.user?.name} </p>
    <h1 className='text-center alert-info' >Login</h1>
    <div className='form-group'>
    <label htmlFor='' >Userid</label>
    <input ref={userid} type="text" className='form-control' placeholder='Type UserId Here' />
    </div>
    <div className='form-group' >
    <label htmlFor='' >PassWord</label>
    <input ref={password} type='password' className='form-control' placeholder='Type Password Here' />
    </div>
    <div className='form-group'>
            <button className='btn btn-primary' onClick={doLogin}>Login</button>
        </div>
    </>
  )
});

export default Login
