import React, { useContext, useState } from 'react'
import { UserContext } from '../../../app/user-context'
import {useForm} from 'react-hook-form';
import { firestore } from '../../../settings/firebase/config';
import { collection, addDoc } from "firebase/firestore";
import { useLocalStorage } from '../hooks/storage-hook';
const Register = () => {
    const context=useContext(UserContext);
    const [message,setMessage]=useState('');
    const {
        register,
        handleSubmit,reset,
        formState: { errors },
      } = useForm();
        const[setLocalStorage,getLocalStorage]=useLocalStorage();
        const addUser=async (userObject)=>{
            console.log('Add User Call ',userObject);
            try{
                const docRef = await addDoc(collection(firestore, "users"), userObject);
                console.log("User Registerd...", docRef.id);
                setLocalStorage('user', userObject);
                console.log('data store in localStorage....');
                console.log('get local storage data is ', getLocalStorage('user'))
                }
                catch(e){
                  console.log('Add User Error.... ', e);
                }
        }

    const onSubmit=(data)=>{
        console.log('Form submitted',data);
        addUser(data);
      }
//   const doRegister = ()=>{
//     const userIdValue = userid.current.value;
//     const passwordValue = userid.current.value;
//     const nameValue = userid.current.value;
//     context.setUser({'userid':userIdValue, 'password':passwordValue, 'name':nameValue});
//     setMessage('Register SuccessFully')

  return (
    <>
    <form onSubmit={handleSubmit(onSubmit)}>
        <h1 className='text-center alert-info'>Register</h1>
        <p className='alert-info'>{message}</p>
        <div className='form-group'>
            <label htmlFor="">Userid</label>
            <input  {...register("userid", {required: true})} type="text" className='form-control' placeholder='Type Userid Here' />
            {errors.userid && errors.userid.type === "required" && (
            <p className="errorMsg">Userid is required.</p>
          )}

        </div>
        <div className='form-group'>
            <label htmlFor="">Password</label>
            <input  {...register("password",{ required: true,
    minLength: 8
})} type="password" className='form-control' placeholder='Type Password Here' />
 {errors.password && errors.password.type === "required" && (
            <p className="errorMsg">Password is required.</p>
          )}
          {errors.password && errors.password.type === "minLength" && (
            <p className="errorMsg">
              Password should be at-least 8 characters.
            </p>
          )}
        </div>
        <div className='form-group'>
            <label htmlFor="">Name</label>
            <input  {...register("name",{required: true})} type="text" className='form-control' placeholder='Type Name Here' />
            {errors.name && errors.name.type === "required" && (
            <p className="errorMsg">Name is required.</p>
          )}
        </div>
        <div className='form-group'>
            <button className='btn btn-primary' type='submit'>Register</button>
        </div>
        </form>
    </>
  )
}
export default Register
