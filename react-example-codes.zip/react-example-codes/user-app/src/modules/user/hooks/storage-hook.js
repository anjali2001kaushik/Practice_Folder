/*
A Custom Hook is just a JS Function , start with "use" word
Used to segerate the logic from the component

*/

export const useLocalStorage = ()=>{
    const setLocalStorage =(key, value)=>{
        localStorage.setItem(key, JSON.stringify(value));
    }
    const getLocalStorage = (key)=>{
        return JSON.parse(localStorage.getItem(key));
    } 
    return [setLocalStorage, getLocalStorage];    
} 