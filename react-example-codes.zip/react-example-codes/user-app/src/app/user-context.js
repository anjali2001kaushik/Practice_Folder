import React, { useState } from 'react';
// Creating a Context with Initlize the Values
export const UserContext=React.createContext({user:{},setUser:()=>null})