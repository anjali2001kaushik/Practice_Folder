import React from 'react'

const Button = ({buttonClick,value}) => {
  return (
    <button className='btn btn-primary' onClick={buttonClick}>{value}</button>
  )
}

export default Button