// write first component
//virtual dom is a collection of objects
import './App.css';
import React from "react";
import { First } from './components/First';
import { Second } from './components/Second';
import Third from './components/Third';
import Fourth from './components/Fourth';


// every component is a function
 const App=()=>{
  const value=3;
  const conditionalRendering=()=>{
    if(value===1){
        return <First msg="Hi" fn={myfn} />
    }
     else if(value===2){
      return <Second/>
    }
    else if(value===3){
      return <Third/>
    }
    else if(value===4) {
      return <Fourth/>
    }
    else {
      return <h1>Nothing....</h1>
    }
  }
  const flag=true; 
  //inline styling
  const myStyle={
    color:'green',
    backgroundColor:'red', 
  };
  const myName='Anjali';
  const myfn=(value)=>{
 console.log('I m the value=',value);
  }
  // return (<h1>Hi React</h1> <h1>Hi React</h1>) //ek saath do object nhi jaaa skte ek hi jaayega
  return (<>
  
  {/* {flag?<First fn={myfn} msg="Hi First...yup"/>:<Second/>} */}
  {conditionalRendering()}
  <h1 className='red'>Hi React {myName}</h1> 
  <h1 style={myStyle}>Hello React</h1>
  </>); 
  // document.createElement(); it creates dom element
  // return(<h1>Hi React Js</h1>)
  // return(<div>
  //   <h1>Hello React Js</h1>
  //   <p>Hi <span>React Js</span></p>
  // </div>)
  // return React.createElement('h1',{style:{backgroundColor:'red'}},'Hi React Js');//virtual Dom Element
  // return React.createElement('div',null,React.createElement('h1',null,'Hello ReactJs'),React.createElement('p',null,'Hi',React.createElement('span',null,'ReactJS')));

}
export default App;