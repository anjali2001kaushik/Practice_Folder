//Bridge file
import ReactDOM from 'react-dom/client';
import App from './App';//virtual dom
const div=document.querySelector('#root');
const root=ReactDOM.createRoot(div);
root.render(<App/>);