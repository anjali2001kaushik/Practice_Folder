export const Second=()=>{
    return(<h1>I'm the second component</h1>);
}