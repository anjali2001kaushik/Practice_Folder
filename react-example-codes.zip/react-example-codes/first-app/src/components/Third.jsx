import React from 'react'

const Third = () => {
    const fruits=["orange",'apple',"mango"];//Array of strings
    const products=[{id:101,name:'cheese pizza',url :'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/margherita.90f9451fd66871fb6f9cf7d506053f18.1.jpg?width=800'},{id:102,name:'margherita', url :'https://api.pizzahut.io/v1/content/en-in/in-1/images/pizza/corn.f8baa08ad7f607f1de30f96bb9245b50.1.jpg?width=375'}];
  return (
    <div><h1>Third component</h1>
    {products.map(product=><div key={product.id}>
      <img src={product.url} alt={product.name} />
      <p>Id {product.id} Name {product.name} price {product.price} </p>
        
    </div>)}
    {fruits.map((fruit,index)=><h1 key={index}> {fruit} Fruit</h1>)}
    </div>
    
  )
}

export default Third