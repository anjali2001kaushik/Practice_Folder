// export const first=(props)=>{
    export const First=({msg,fn})=>{
        fn(1000);
        return (<h1>First Component{msg}</h1>)
    // return (<h1>First Component{props.msg}</h1>)
}