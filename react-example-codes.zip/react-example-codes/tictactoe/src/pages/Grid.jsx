import React from 'react'
import Cell from '../components/Cell';
import { useState } from 'react'

export const Grid = (props) => {
    // console.log('All Child',props);
    const[XorZeroFlag,setXorZeroFlag]=useState(false);
    const toggleIt=()=>{
        setXorZeroFlag(!XorZeroFlag)
    }
  return (
    <div className='container'>
        <h1 className='alert-info text-centre'>TicTactoe</h1>
        <table>
            <tr>
                {/* <cell isXorZero={XorZeroFlag} fn={toggleIt} />
                <cell isXorZero={XorZeroFlag} fn={toggleIt} /> isse sb jgh rendering ho jaayegi */}
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
            </tr>
            <tr>
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
            </tr>
            <tr>
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
                <Cell isxorZero={XorZeroFlag} fn={toggleIt} />
            </tr>
        </table>
    </div>
  )
}
