import { Grid } from "./pages/Grid";
const App=()=>{
  return(<Grid/>);
}
export default App;