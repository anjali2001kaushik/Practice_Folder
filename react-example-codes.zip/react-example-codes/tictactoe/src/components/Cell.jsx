import React from 'react'
import { useState } from 'react';

 const Cell = ({isxorZero,fn}) => {
    console.log('Cell Render call');
    const [val,setVal]=useState('');
    const toggle=()=>{
        
        if(!val){
            fn();//Parent ka set state chlta haoi
            setVal(isxorZero?"X":"0");//child ka set state
        }
        
    }
  return (
        <td>
          <button onClick={toggle} className='btn btn-primary'>{val}</button>
        </td>
    
  )
}
export default Cell;